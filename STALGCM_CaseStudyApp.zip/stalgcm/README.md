
# Disclosure
Maven for some reason cannot include LanguageTool in the .jar file as it could not detect the main class. Thus, the jar file will not work
As such, this file is to prove that we used the most recent LanguageTool version by creating our own application to run the updated repository.

# Instructions to Run the Program

1. Install Maven
2. Open console, make the STALGCM Folder as main directory with cd command.
3. Type the following commands
- mvn clean compile
- mvn exec:java

4. Read output.txt for the output of program